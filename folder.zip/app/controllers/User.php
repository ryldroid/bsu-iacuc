<?php

class User extends Controller
{
  // ===== INPUT HELPERS =====
  private function normalizePhoneNumber(string $raw): string
  {
    $digits = preg_replace('/\D/', '', $raw);

    if ($digits === '') {
      return '';
    }

    if (str_starts_with($digits, '63') && strlen($digits) > 10) {
      $digits = substr($digits, 2);
    }

    if ($digits[0] === '0') {
      $digits = substr($digits, 1);
    }

    return '+63' . $digits;
  }

  private function sanitizeInputs(array $post): array
  {
    return [
      'username'     => trim(preg_replace('/[^a-zA-Z0-9_-]/', '', $post['username'] ?? '')),
      'first_name'   => ucfirst(mb_strtolower(trim(preg_replace('/[^\p{L}\p{M}\s\-\']/u', '', $post['first_name'] ?? '')))),
      'last_name'    => trim(preg_replace('/[^\p{L}\p{M}\s\-\']/u', '', $post['last_name'] ?? '')),
      'email'        => filter_var(trim($post['email'] ?? ''), FILTER_SANITIZE_EMAIL),
      'phone_number' => $this->normalizePhoneNumber($post['phone_number'] ?? ''),
      'school'       => trim(preg_replace('/[^\p{L}\p{M}\p{N}\s\-\'\.,()&]/u', '', $post['school'] ?? '')),
      'sex'          => in_array($post['sex'] ?? '', ['Male', 'Female'], true) ? $post['sex'] : '',
      'password'     => $post['password'] ?? '',
      'confirm_pass' => $post['confirm_password'] ?? '',
      'role'         => $post['role'] ?? '',
    ];
  }

  private function validateUserFields(
    string $username,
    string $first_name,
    string $last_name,
    string $email,
    string $phone_number,
    string $password,
    string $confirm_pass,
    string $role,
    bool $password_required = true,
    string $sex = ''
  ): array {
    $errors = [];

    if (empty($sex)) {
      $errors[] = 'Please select your sex.';
    }

    if (empty($username)) {
      $errors[] = 'Username is required.';
    } elseif (strlen($username) < 3 || strlen($username) > 50) {
      $errors[] = 'Username must be 3–50 characters (letters, numbers, _ or -).';
    }

    if (preg_match('/[^\p{L}\p{M}\s\-\']/u', $first_name)) {
      $errors[] = 'First name contains invalid characters. Only letters from any language, spaces, hyphens, and apostrophes are allowed.';
    } elseif (empty($first_name) || strlen($first_name) < 2 || strlen($first_name) > 100) {
      $errors[] = 'First name must be at least 2 characters.';
    }

    if (preg_match('/[^\p{L}\p{M}\s\-\']/u', $last_name)) {
      $errors[] = 'Last name contains invalid characters. Only letters from any language, spaces, hyphens, and apostrophes are allowed.';
    } elseif (empty($last_name) || strlen($last_name) < 2 || strlen($last_name) > 100) {
      $errors[] = 'Last name must be at least 2 characters.';
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $errors[] = 'A valid email address is required.';
    }

    if (empty($phone_number)) {
      $errors[] = 'Phone number is required.';
    } else {
      if (preg_match('/[a-zA-Z]/', $phone_number)) {
        $errors[] = 'Phone number cannot contain letters. Please enter numbers only.';
      } elseif (!preg_match('/^\+639\d{9}$/', $phone_number)) {
        $errors[] = 'Enter a valid Philippine phone number (e.g., +639171234567)';
      }
    }

    if ($password_required || !empty($password) || !empty($confirm_pass)) {
      $pw_reqs = $this->validatePasswordRequirements($password);
      if (!empty($pw_reqs)) {
        $errors[] = 'Password must contain: ' . implode(', ', $pw_reqs) . '.';
      }
      if ($password !== $confirm_pass) {
        $errors[] = 'Passwords do not match.';
      }
    }

    $valid_roles = ['researcher', 'staff', 'reviewer'];
    if (!in_array($role, $valid_roles)) {
      $errors[] = 'Please select a valid role.';
    }

    return $errors;
  }

  // ===== LOG IN =====

  public function login()
  {
    if ($this->isLoggedIn()) {
      $this->redirect('submissions');
    }

    $prefill = $_SESSION['new_username'] ?? $_SESSION['new_email'] ?? '';
    unset($_SESSION['new_username'], $_SESSION['new_email']);

    $this->view('user/login', [
      'prefill' => $prefill,
      'error'   => $_SESSION['flash_error'] ?? '',
      'csrf'    => $this->generateCsrfToken(),
    ]);
    unset($_SESSION['flash_error']);
  }

  public function login_process()
  {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      $this->redirect('user/login');
    }

    $this->verifyCsrfToken(true);

    // ===== READ INPUT =====
    $input    = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $ip       = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

    // ===== LOGIN ATTEMPT LIMIT =====
    $MAX_ATTEMPTS = 5;
    $WINDOW       = 900;

    $ipAttempts   = $this->userModel->countRecentAttempts($ip, $WINDOW);
    $userAttempts = $this->userModel->countRecentAttempts($input, $WINDOW);

    if ($ipAttempts >= $MAX_ATTEMPTS || $userAttempts >= $MAX_ATTEMPTS) {
      $this->userModel->logAudit('login_locked', null, $input, '', 'user', null, 'Login temporarily locked after repeated failed attempts');
      $_SESSION['flash_error'] = 'Too many failed login attempts. Please wait 15 minutes before trying again.';
      $this->redirect('user/login');
    }

    if (empty($input) || empty($password)) {
      $_SESSION['flash_error'] = 'Please fill in all fields.';
      $this->redirect('user/login');
    }

    // ===== FIND USER & CHECK PASSWORD =====
    $user = $this->userModel->getUserByUsername($input)
      ?? $this->userModel->getUserByEmail($input);

    if (!$user) {
      $this->userModel->recordLoginAttempt($ip);
      $this->userModel->recordLoginAttempt($input);
      $this->userModel->logAudit('login_failed', null, $input, '', '', null, 'Failed login attempt (no account found)');
      $_SESSION['flash_error'] = 'No researcher account found with that username or email.';
      $this->redirect('user/login');
    }

    if (!password_verify($password, $user['password'])) {
      $this->userModel->recordLoginAttempt($ip);
      $this->userModel->recordLoginAttempt($input);
      $_SESSION['flash_error'] = 'Invalid password. Please try again.';

      $this->userModel->logAudit(
        event: 'login_failed',
        actorId: null,
        actorUsername: $input,
        actorRole: '',
        targetType: '',
        targetId: null,
        description: 'Failed login attempt (wrong password)'
      );

      $this->redirect('user/login');
    }

    // ===== ACCOUNT CHECKS =====
    $this->userModel->clearLoginAttempts($ip);
    $this->userModel->clearLoginAttempts($input);

    if ($user['role'] !== 'researcher') {
      $_SESSION['flash_error'] = 'No researcher account found with that username or email.';
      $this->redirect('user/login');
    }

    $reactivated = false;
    if (($user['status'] ?? 'active') === 'deactivated') {
      $this->userModel->reactivateUser((int) $user['id']);
      $reactivated = true;
    }

    // ===== START SESSION =====
    session_regenerate_id(true);
    $_SESSION['user'] = [
      'user_id'        => $user['id'],
      'first_name'     => $user['first_name'],
      'username'       => $user['username'],
      'email'          => $user['email'],
      'role'           => $user['role'],
      'email_verified' => (bool) $user['email_verified'],
    ];

    // ===== WELCOME POPUP =====
    if (empty($user['welcome_seen'])) {
      $_SESSION['user']['show_welcome'] = true;
      $this->userModel->markWelcomeSeen((int) $user['id']);
    }

    // ===== LOG LOGIN & REDIRECT =====
    $this->userModel->logAudit(
      event: 'login_success',
      actorId: (int)$user['id'],
      actorUsername: $user['username'],
      actorRole: $user['role'],
      targetType: 'user',
      targetId: (int)$user['id'],
      description: 'Researcher logged in'
    );

    if ($reactivated) {
      $this->userModel->logAudit('account_reactivated', (int) $user['id'], $user['username'], $user['role'], 'user', (int) $user['id'], 'Account reactivated by logging in');
      $_SESSION['flash_success'] = 'Welcome back! Your account has been reactivated.';
    }

    $this->redirect('submissions');
  }

  // ===== REGISTER =====

  public function register()
  {
    if ($this->isLoggedIn()) {
      $this->redirect('submissions');
    }

    $this->view('user/register', [
      'errors' => [],
      'old'    => [],
      'csrf'   => $this->generateCsrfToken(),
    ]);
  }

  public function register_process()
  {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      $this->redirect('user/register');
    }

    $this->verifyCsrfToken();

    extract($this->sanitizeInputs($_POST));
    $school = trim($school ?? '');
    $old = compact('username', 'first_name', 'last_name', 'email', 'phone_number', 'school', 'sex');

    $errors = $this->validateUserFields($username, $first_name, $last_name, $email, $phone_number, $password, $confirm_pass, 'researcher', true, $sex);

    if ($school === '') {
      $errors[] = 'Please enter your school.';
    } elseif (mb_strlen($school) > 150) {
      $errors[] = 'School name is too long.';
    }

    if (empty($errors)) {
      if ($this->userModel->getUserByEmail($email)) {
        $errors[] = 'That email is already taken.';
      }
      if ($this->userModel->getUserByUsername($username)) {
        $errors[] = 'That username is already taken.';
      }
    }

    if (!empty($errors)) {
      $this->view('user/register', [
        'errors' => $errors,
        'old'    => $old,
        'csrf'   => $this->generateCsrfToken(),
      ]);
      return;
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $ok   = $this->userModel->insertUser($username, $first_name, $last_name, $email, $hash, 'researcher', 'active', $phone_number, $school, $sex);

    if ($ok) {
      $_SESSION['new_username'] = $username;
      $this->view('user/register', [
        'errors'  => [],
        'old'     => [],
        'csrf'    => $this->generateCsrfToken(),
        'success' => true,
      ]);
    } else {
      $errors[] = 'Registration failed. Please try again.';
      $this->view('user/register', [
        'errors' => $errors,
        'old'    => $old,
        'csrf'   => $this->generateCsrfToken(),
      ]);
    }
  }

  // ===== LOG OUT =====

  public function logout()
  {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      $this->redirect('home');
    }

    $uid      = $_SESSION['user']['user_id'] ?? null;
    $uname    = $_SESSION['user']['username'] ?? '';
    $urole    = $_SESSION['user']['role'] ?? '';

    $this->userModel->logAudit('logout', $uid, $uname, $urole, 'user', $uid, 'User logged out');

    session_destroy();
    session_start();
    $this->redirect('home');
  }

  // ===== SESSION PING  (POST /user/ping) =====

  public function ping(): void
  {
    $this->requireLogin();
    header('Content-Type: application/json');
    $this->requirePostMethod();
    $this->verifyCsrfHeader();

    echo json_encode(['ok' => true]);
    exit;
  }

  // ===== MANAGE ACCOUNT =====

  public function account()
  {
    $this->requireLogin();

    $user = $this->userModel->getUser($_SESSION['user']['user_id']);

    $certificate = ($user['role'] ?? '') === 'researcher'
      ? $this->userModel->getCert((int) $user['id'])
      : null;

    $this->view('user/account', [
      'csrf'           => $this->generateCsrfToken(),
      'errors'         => !empty($_SESSION['flash_error']) ? [$_SESSION['flash_error']] : [],
      'certificate'    => $certificate,
      'email_verified' => (bool) $user['email_verified'],
      'email_notifications' => (bool) $user['email_notifications'],
      'email_provider_blocked' => (bool) $user['email_provider_blocked'],
      'old'         => [
        'first_name'   => $user['first_name'],
        'last_name'    => $user['last_name'],
        'username'     => $user['username'],
        'email'        => $user['email'],
        'phone_number' => $user['phone_number'] ?? '+63',
        'school'       => $user['school'] ?? '',
        'sex'          => $user['sex'] ?? '',
        'role'         => $user['role'],
      ],
    ]);
    unset($_SESSION['flash_error']);
  }

  // ===== EMAIL NOTIFICATIONS TOGGLE (POST /user/notifications) =====

  public function notifications(): void
  {
    $this->requireLogin();

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      $this->redirect('user/account');
    }

    $this->verifyCsrfToken();

    $id      = (int) $_SESSION['user']['user_id'];
    $email   = $_SESSION['user']['email'];
    $enabled = !empty($_POST['email_notifications']);

    $this->userModel->updateEmailNotifications($id, $enabled);

    if ($enabled) {
      $resubscribed = Mailer::resubscribe($email);
      $this->userModel->updateEmailProviderBlocked($id, !$resubscribed);

      $_SESSION['flash_success'] = $resubscribed
        ? 'You will now receive email updates about your protocols.'
        : 'Preference saved, but we couldn\'t confirm with our email provider that you\'re unblocked. If you previously unsubscribed via email, you may need to try again shortly.';
    } else {
      $_SESSION['flash_success'] = 'Email updates about your protocols have been turned off.';
    }

    $this->redirect('user/account');
  }

  // ===== UPDATE ACCOUNT =====
  public function update()
  {
    $this->requireLogin();

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      $this->redirect('user/account');
    }

    $this->verifyCsrfToken();

    $id = (int) $_SESSION['user']['user_id'];

    // ===== CLEAN INPUT & VALIDATE =====
    extract($this->sanitizeInputs($_POST));

    $current_user = $this->userModel->getUser($id);

    if ($current_user['role'] === 'researcher') {
      $role = $current_user['role'];
    } else {
      $role = in_array($role, ['staff', 'reviewer']) ? $role : $current_user['role'];
    }

    $school = trim($school ?? '');
    $old = compact('username', 'first_name', 'last_name', 'email', 'phone_number', 'school', 'sex', 'role');

    $errors = $this->validateUserFields($username, $first_name, $last_name, $email, $phone_number, $password, $confirm_pass, $role, false, $sex);

    if ($role === 'researcher') {
      if ($school === '') {
        $errors[] = 'Please enter your school.';
      } elseif (mb_strlen($school) > 150) {
        $errors[] = 'School name is too long.';
      }
    }

    if (empty($errors)) {
      $existing_email    = $this->userModel->getUserByEmail($email);
      $existing_username = $this->userModel->getUserByUsername($username);

      if ($existing_email && (int) $existing_email['id'] !== $id) {
        $errors[] = 'That email is already taken.';
      }
      if ($existing_username && (int) $existing_username['id'] !== $id) {
        $errors[] = 'That username is already taken.';
      }
    }

    // ===== SHOW ERRORS =====
    if (!empty($errors)) {
      $certificate = $current_user['role'] === 'researcher'
        ? $this->userModel->getCert($id)
        : null;

      $this->view('user/account', [
        'csrf'        => $this->generateCsrfToken(),
        'errors'      => $errors,
        'certificate' => $certificate,
        'email_verified'      => (bool) $current_user['email_verified'],
        'email_notifications' => (bool) $current_user['email_notifications'],
        'email_provider_blocked' => (bool) $current_user['email_provider_blocked'],
        'old'         => $old,
      ]);
      return;
    }

    // ===== SAVE CHANGES =====
    $input = compact('username', 'first_name', 'last_name', 'email', 'phone_number', 'school', 'sex', 'role');
    if (!empty($password)) {
      $input['password'] = password_hash($password, PASSWORD_DEFAULT);
    }

    $ok = $this->userModel->updateUser($id, $input);

    // ===== AFTER SAVE =====
    if ($ok) {
      $_SESSION['user']['first_name'] = $first_name;
      $_SESSION['user']['username']   = $username;
      $_SESSION['user']['email']      = $email;
      $_SESSION['user']['role'] = $role;

      if (!empty($password)) {
        $this->userModel->logAudit('password_changed', $id, $username, $role, 'user', $id, 'Password changed via account settings');
      }

      if ($email !== $current_user['email']) {
        $this->userModel->markEmailUnverified($id);
        $this->sendEmailVerification(['id' => $id, 'first_name' => $first_name, 'email' => $email]);
        $_SESSION['user']['email_verified'] = false;

        $this->userModel->logAudit('email_changed', $id, $username, $role, 'user', $id, 'Email changed, re-verification sent');

        $_SESSION['flash_success'] = 'Account updated successfully! Verify your new email to keep getting email notifications.';
      } else {
        $_SESSION['flash_success'] = 'Account updated successfully!';
      }
    } else {
      $_SESSION['flash_error'] = 'Update failed. Please try again.';
    }

    $this->redirect('user/account');
  }

  // ===== DELETE ACCOUNT =====
  public function delete()
  {
    $this->requireLogin();

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      $this->redirect('user/account');
    }

    $this->verifyCsrfToken();

    $id       = (int) $_SESSION['user']['user_id'];
    $username = $_SESSION['user']['username'] ?? '';
    $role     = $_SESSION['user']['role'] ?? '';

    (new ProtocolModel())->softDeleteAllForUser($id, $username, 'Account deleted by owner');

    (new DraftModel())->clear($id);
    $draftDir = dirname(__DIR__, 2) . '/storage/uploads/drafts/' . $id . '/';
    if (is_dir($draftDir)) {
      $this->rrmdir($draftDir);
    }

    $ok = $this->userModel->deleteUser($id);

    if ($ok) {
      $this->userModel->logAudit('account_deleted', $id, $username, $role, 'user', $id, 'User deleted their account');

      session_destroy();
      session_start();
      $_SESSION['flash_success'] = 'Your account has been deleted.';
      $this->redirect('user/login');
    }

    $_SESSION['flash_error'] = 'Account deletion failed. Please try again or contact support.';
    $this->redirect('user/account');
  }

  // ===== FOLDER CLEANUP HELPER =====
  private function rrmdir(string $dir): void
  {
    $items = @scandir($dir);
    if ($items === false) {
      return;
    }

    foreach ($items as $item) {
      if ($item === '.' || $item === '..') {
        continue;
      }
      $path = $dir . $item;
      if (is_dir($path)) {
        $this->rrmdir($path);
      } else {
        @unlink($path);
      }
    }

    @rmdir($dir);
  }

  // ===== FORGOT / RESET PASSWORD =====
  public function forgot_password(): void
  {
    if ($this->isLoggedIn()) {
      $this->redirect('submissions');
    }

    $this->handleForgotPassword(
      'user/forgot_password',
      'user/reset_password',
      'user/login'
    );
  }

  public function reset_password(): void
  {
    $this->handleResetPassword(
      'user/reset_password',
      'user/login'
    );
  }

  // ===== EMAIL VERIFICATION =====
  public function verify_email(): void
  {
    $token  = $_GET['token'] ?? '';
    $record = $this->userModel->getEmailVerification($token);

    if (!$record) {
      $_SESSION['flash_error'] = 'This verification link is invalid or has expired.';
      $this->redirect($this->isLoggedIn() ? 'user/account' : 'user/login');
      return;
    }

    $userId = (int) $record['user_id'];

    $this->userModel->markEmailVerified($userId);
    $this->userModel->markEmailVerificationUsed($token);
    $this->userModel->logAudit('email_verified', $userId, '', '', 'user', $userId, 'Email verified');

    $_SESSION['flash_success'] = 'Your email has been verified!';
    $this->redirect($this->isLoggedIn() ? 'user/account' : 'user/login');
  }

  public function resend_verification(): void
  {
    $this->requireLogin();

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      $this->redirect('user/account');
    }

    $this->verifyCsrfToken();

    $id   = (int) $_SESSION['user']['user_id'];
    $user = $this->userModel->getUser($id);

    $back = $_SERVER['HTTP_REFERER'] ?? (ROOT . '/user/account');

    if (!empty($user['email_verified'])) {
      header('Location: ' . $back);
      exit;
    }

    $cooldown  = 45;
    $elapsed   = $this->userModel->secondsSinceLastVerificationEmail($id);

    if ($elapsed !== null && $elapsed < $cooldown) {
      $_SESSION['flash_error'] = 'Please wait ' . ($cooldown - $elapsed) . ' seconds before requesting another verification link.';
      header('Location: ' . $back);
      exit;
    }

    $this->sendEmailVerification($user);
    $_SESSION['flash_success'] = 'Verification link sent to your email. Please check your inbox.';
    header('Location: ' . $back);
    exit;
  }
}
