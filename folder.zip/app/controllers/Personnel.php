<?php

class Personnel extends Controller
{
    private RecordModel $recordModel;
    private ProtocolModel $protocolModel;
    private AnnouncementModel $announcementModel;
    private SiteSettingModel $settingsModel;
    private ContactOfficeModel $officeModel;
    private FaqModel $faqModel;

    // ===== SETUP & ACCESS CHECKS =====
    public function __construct()
    {
        parent::__construct();

        $this->recordModel       = new RecordModel();
        $this->protocolModel     = new ProtocolModel();
        $this->announcementModel = new AnnouncementModel();
        $this->settingsModel     = new SiteSettingModel();
        $this->officeModel       = new ContactOfficeModel();
        $this->faqModel          = new FaqModel();
    }

    private function requireStaff(bool $ajax = false): void
    {
        $this->requirePersonnel($ajax);
        if ($_SESSION['user']['role'] !== 'staff') {
            $ajax
                ? $this->jsonError(403, 'Administrative staff access required.')
                : $this->redirect('personnel/home');
        }
    }

    private function requirePersonnel(bool $ajax = false): void
    {
        if (!$this->isLoggedIn()) {
            $ajax
                ? $this->jsonError(401, 'Your session has expired. Please log in again.')
                : $this->redirect('personnel/login');
        }
        if (!$this->isPersonnel()) {
            $ajax
                ? $this->jsonError(401, 'Your session has expired. Please log in again.')
                : $this->redirect('personnel/login');
        }
    }

    protected function jsonError(int $code, string $message): void
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'message' => $message]);
        exit;
    }

    // ===== DASHBOARD =====
    public function home(): void
    {
        $this->requirePersonnel();

        $this->recordModel->runExpiryDeactivationSweep();

        $protocols = $this->protocolModel->getAll();

        foreach ($protocols as &$protocol) {
            $protocol['can_endorse'] = $protocol['status'] === 'Reviewed'
                && ($protocol['payment_status'] ?? 'unpaid') === 'paid'
                && !empty($protocol['reference_no'])
                && !empty($protocol['latest_signed_scan_version_id']);
        }
        unset($protocol);

        $statuses = ['Under Review', 'Needs Revision', 'Reviewed', 'Endorsed', 'Approved'];

        $activityTimestamps = array_column($protocols, 'last_activity_at');
        $updatesBaseline    = $activityTimestamps ? max($activityTimestamps) : null;

        $this->view('personnel/personnel-home', [
            'user'            => $_SESSION['user'],
            'csrf'            => $this->generateCsrfToken(),
            'protocols'       => $protocols,
            'statuses'        => $statuses,
            'updatesEndpoint' => 'personnel/checkupdates',
            'updatesBaseline' => $updatesBaseline,
        ]);
    }

    // ===== LIVE UPDATE CHECK =====
    public function checkupdates(): void
    {
        $this->requirePersonnel(true);
        header('Content-Type: application/json');

        echo json_encode(['latest' => $this->protocolModel->getLatestActivityTimestamp()]);
        exit;
    }

    // ===== RESEARCHER DETAILS =====
    public function researcher_details(): void
    {
        $this->requirePersonnel(true);
        header('Content-Type: application/json');

        $id   = (int) ($_GET['id'] ?? 0);
        $user = $id > 0 ? $this->userModel->getUser($id) : null;

        if (! $user) {
            echo json_encode(['ok' => false, 'message' => 'Researcher not found.']);
            exit;
        }

        $protocols     = $this->protocolModel->getByUser($id);

        echo json_encode([
            'ok'   => true,
            'data' => [
                'first_name'     => $user['first_name'],
                'last_name'      => $user['last_name'],
                'username'       => $user['username'],
                'email'          => $user['email'],
                'phone_number'   => $user['phone_number'] ?? '',
                'school'         => $user['school'] ?? '',
                'role'           => $user['role'],
                'status'         => $user['status'],
                'created_at'     => $user['created_at'],
                'protocol_count' => count($protocols),
                'protocols'      => array_map(fn($p) => [
                    'reference_no'   => $p['reference_no'],
                    'research_title' => $p['research_title'],
                    'status'         => $p['status'],
                    'submitted_at'   => $p['submitted_at'],
                ], array_slice($protocols, 0, 5)),
            ],
        ]);
        exit;
    }

    // ===== CLEARANCES REDIRECT =====
    public function clearances(): void
    {
        $this->requireStaff();

        $this->redirect('personnel/home?status=endorsed');
    }

    // ===== RECORDS LIST =====
    public function records(): void
    {
        $this->requirePersonnel();

        $this->recordModel->runExpiryDeactivationSweep();

        $search         = trim($_GET['search'] ?? '');
        $school         = trim($_GET['school'] ?? '');
        $animalType     = trim($_GET['animal'] ?? '');
        $sex         = trim($_GET['sex'] ?? '');
        $researcherType = trim($_GET['rtype']  ?? '');
        $status         = trim($_GET['status'] ?? '');
        if (! in_array($status, RecordModel::STATUSES, true)) {
            $status = '';
        }
        $sort           = trim($_GET['sort']   ?? '') ?: 'newest';
        $periodPreset   = trim($_GET['period'] ?? '');
        if (! isset(RecordModel::PERIOD_PRESETS[$periodPreset])) {
            $periodPreset = RecordModel::DEFAULT_PERIOD;
        }
        $periodFrom     = trim($_GET['from']   ?? '');
        $periodTo       = trim($_GET['to']     ?? '');
        $period         = $this->recordModel->resolvePeriod($periodPreset, $periodFrom, $periodTo);
        $perPage        = 25;
        $page           = max(1, (int) ($_GET['page'] ?? 1));
        $offset         = ($page - 1) * $perPage;

        $total      = $this->recordModel->count($search, $school, $animalType, $sex, $researcherType, $status);
        $records    = $this->recordModel->getAll($search, $school, $animalType, $sex, $researcherType, $sort, $perPage, $offset, null, $status);
        $totalPages = (int) ceil($total / $perPage);

        $this->view('personnel/personnel-records', [
            'user'            => $_SESSION['user'],
            'csrf'            => $this->generateCsrfToken(),
            'records'         => $records,
            'total'           => $total,
            'page'            => $page,
            'totalPages'      => $totalPages,
            'perPage'         => $perPage,
            'search'          => $search,
            'school'          => $school,
            'animalType'      => $animalType,
            'sex'          => $sex,
            'researcherType'  => $researcherType,
            'status'          => $status,
            'sort'            => $sort,
            'schools'         => $this->recordModel->distinctValues('school'),
            'animalTypes'     => $this->recordModel->distinctValues('animal_type'),
            'sexes'         => $this->recordModel->distinctValues('sex'),
            'researcherTypes' => $this->recordModel->distinctValues('researcher_type'),
            'stats'           => $this->recordModel->stats($period),
            'period'          => $period,
            'periodPreset'    => $periodPreset,
            'periodFrom'      => $period['from'] ?? $periodFrom,
            'periodTo'        => $period['to'] ?? $periodTo,
            'flash_success'   => $_SESSION['flash_success'] ?? '',
            'flash_error'     => $_SESSION['flash_error']   ?? '',
        ]);
        unset($_SESSION['flash_success'], $_SESSION['flash_error']);
    }

    // ===== RECORD FILE =====
    public function records_file(int $recordId = 0): void
    {
        $this->requirePersonnel();

        if ($recordId < 1) {
            $this->renderError(400, 'Missing Record ID', [
                'No record was specified.',
            ]);
        }

        $record = $this->recordModel->getById($recordId);

        if (!$record || empty($record['file_path'])) {
            $this->renderError(404, 'File Not Found', [
                'The file you are looking for does not exist or may have been removed.',
            ]);
        }

        $filePath = dirname(__DIR__, 2) . '/storage/uploads/records/' . $record['file_path'];

        if (!file_exists($filePath) || !is_readable($filePath)) {
            $this->renderError(404, 'File Not Found', [
                'The file could not be found on the server.',
            ]);
        }

        $this->streamFile($filePath, $record['file_original_name'] ?: basename($filePath), isset($_GET['download']));
    }

    // ===== ADD RECORD =====
    public function records_add(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $ref   = trim($_POST['reference_no'] ?? '');

        if ($ref === '') {
            $this->jsonError(422, 'IPN is required.');
        }
        if (!preg_match('/^\d{6}$/', $ref)) {
            $this->jsonError(422, 'IPN must be 6 digits, with the last 2 digits as the year (e.g. 000026).');
        }
        if ($this->recordModel->refExists($ref)) {
            $this->jsonError(422, 'That IPN already exists.');
        }

        $d = $this->sanitizeRecordPost();
        if ($d['ar_number'] !== '' && $this->recordModel->arExists($d['ar_number'])) {
            $this->jsonError(422, 'That AR number already exists.');
        }
        $ok = $this->recordModel->insert($d);

        if ($ok) {
            $actor = $this->actor();
            $this->recordModel->logAudit('record_added', $actor['id'], $actor['name'], $actor['role'], 'record', null, "Record added: $ref");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Record added.' : 'Insert failed.']);
        exit;
    }

    // ===== GET RECORD =====
    public function records_get(): void
    {
        $this->requireStaff(true);
        header('Content-Type: application/json');

        $id    = (int) ($_GET['id'] ?? 0);
        $row   = $id > 0 ? $this->recordModel->getById($id) : null;

        if ($row) {
            $row['has_signed_scan'] = !empty($row['protocol_id'])
                && $this->protocolModel->getLatestVersion((int) $row['protocol_id'], 'signed_scan') !== null;
        }

        echo json_encode(
            $row
                ? ['ok' => true, 'data' => $row]
                : ['ok' => false, 'message' => 'Record not found.']
        );
        exit;
    }

    // ===== EDIT RECORD =====
    public function records_edit(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $id    = (int) ($_POST['id'] ?? 0);

        if ($id < 1 || !$this->recordModel->exists($id)) {
            $this->jsonError(404, 'Record not found.');
        }

        $d       = $this->sanitizeRecordPost();
        $d['id'] = $id;
        $existingRec = $this->recordModel->getById($id);
        $ipnChanged  = $d['reference_no'] !== '' && $d['reference_no'] !== ($existingRec['reference_no'] ?? '');
        if ($ipnChanged && !preg_match('/^\d{6}$/', $d['reference_no'])) {
            $this->jsonError(422, 'IPN must be 6 digits, with the last 2 digits as the year (e.g. 000026).');
        }
        if ($d['ar_number'] !== '' && $this->recordModel->arExists($d['ar_number'], $id)) {
            $this->jsonError(422, 'That AR number already exists.');
        }
        $ok      = $this->recordModel->update($d);

        if ($ok) {
            $actor = $this->actor();
            $ref   = $d['reference_no'] !== '' ? "IPN {$d['reference_no']}" : ($d['title_of_research'] !== '' ? $d['title_of_research'] : "record #$id");
            $this->recordModel->logAudit('record_edited', $actor['id'], $actor['name'], $actor['role'], 'record', $id, "Record edited: $ref");

            $record = $this->recordModel->getById($id);
            if ($record && !empty($record['protocol_id']) && $d['reference_no'] !== '') {
                $this->protocolModel->setReferenceNo((int) $record['protocol_id'], $d['reference_no']);
            }
            if ($record && !empty($record['protocol_id']) && $d['ar_number'] !== '') {
                $this->protocolModel->setArNumber((int) $record['protocol_id'], $d['ar_number']);
            }
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Record updated.' : 'Update failed.']);
        exit;
    }

    // ===== DELETE RECORD =====
    public function records_delete(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $id    = (int) ($_POST['id'] ?? 0);

        if ($id < 1) {
            $this->jsonError(400, 'No record id given.');
        }

        $record = $this->recordModel->getById($id);
        $ok     = $this->recordModel->delete($id);

        if ($ok) {
            $actor = $this->actor();
            $ref   = $record && $record['reference_no'] !== '' ? "IPN {$record['reference_no']}" : ($record['title_of_research'] ?? "record #$id");
            $this->recordModel->logAudit('record_deleted', $actor['id'], $actor['name'], $actor['role'], 'record', $id, "Record deleted: $ref");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Record deleted.' : 'Delete failed.']);
        exit;
    }

    // ===== EXPORT RECORDS (XLSX) =====
    public function records_export(): void
    {
        $this->requirePersonnel();

        // ===== READ PERIOD =====
        $periodPreset = trim($_GET['period'] ?? '');
        if (! isset(RecordModel::PERIOD_PRESETS[$periodPreset])) {
            $periodPreset = RecordModel::DEFAULT_PERIOD;
        }
        $period = $this->recordModel->resolvePeriod(
            $periodPreset,
            trim($_GET['from'] ?? ''),
            trim($_GET['to']   ?? '')
        );

        // ===== LOAD DATA =====
        $records = $this->recordModel->getAll('', '', '', '', '', 'newest', 1000000, 0, $period);
        $stats   = $this->recordModel->stats($period);

        // ===== STATISTICS SHEET =====
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();

        $statsSheet = $spreadsheet->getActiveSheet();
        $statsSheet->setTitle('Statistics');
        $this->writeStatisticsSheet($statsSheet, $stats, $period['label'] ?? 'All time');

        // ===== RECORDS SHEET =====
        $recordsSheet = $spreadsheet->createSheet();
        $recordsSheet->setTitle('Records');

        $headers = [
            'IPN',
            'AR Number',
            'Title of Research',
            'School',
            'Animal Type',
            'Count',
            'Researcher',
            'Researcher Sex',
            'Researcher Type',
            'Research Adviser',
            'Veterinarian',
            'Duration',
            'Date Released',
            'Received By',
            'Status',
        ];
        $recordsSheet->fromArray($headers, null, 'A1');

        $row = 2;
        foreach ($records as $r) {
            $recordsSheet->fromArray([
                $r['reference_no'],
                $r['ar_number'] ?? '',
                $r['title_of_research'],
                $r['school'] ?? '',
                $r['animal_type'] ?? '',
                $r['animal_count'] ?? '',
                $r['principal_investigator'] ?? '',
                $r['sex'] ?? '',
                $r['researcher_type'] ?? '',
                $r['research_adviser'] ?? '',
                $r['veterinarian'] ?? '',
                $this->formatDurationRange($r['research_duration_start'] ?? null, $r['research_duration_end'] ?? null),
                $r['date_released'] ? date(DATE_FORMAT, strtotime($r['date_released'])) : '',
                $r['received_by'] ?? '',
                $r['status'] ?? RecordModel::DEFAULT_STATUS,
            ], null, "A$row");
            $row++;
        }

        foreach (range('A', 'O') as $column) {
            $recordsSheet->getColumnDimension($column)->setAutoSize(true);
        }

        // ===== LOG & SEND FILE =====
        $spreadsheet->setActiveSheetIndex(0);

        $actor = $this->actor();
        $this->recordModel->logAudit('records_exported', $actor['id'], $actor['name'], $actor['role'], 'records', null, 'Exported records to Excel');

        $filename = 'iacuc-records-' . date('Y-m-d_His') . '.xlsx';

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');

        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }


    // ===== EXPORT HELPERS =====
    private function writeStatisticsSheet(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, array $stats, string $periodLabel): void
    {
        $row = 1;
        $sheet->setCellValue("A$row", 'BSU-IACUC Records:  Statistics Summary');
        $sheet->getStyle("A$row")->getFont()->setBold(true)->setSize(14);
        $row++;

        $sheet->setCellValue("A$row", 'Generated: ' . date(DATETIME_FORMAT));
        $row++;

        $sheet->setCellValue("A$row", "Period: $periodLabel");
        $row += 2;

        $sheet->setCellValue("A$row", 'Summary');
        $sheet->getStyle("A$row")->getFont()->setBold(true);
        $row++;

        foreach (
            [
                ['Protocols Reviewed', $stats['reviewed']],
                ['Protocols Revised', $stats['revised']],
                ['Revision Submissions', $stats['revision_submissions']],
                ['Average Revisions per Revised Protocol', $stats['avg_revisions']],
                ['Protocols Endorsed', $stats['endorsed']],
                ['Protocols Signed by IACUC Chair', $stats['signed']],
                ['Clearances Returned', $stats['clearances_returned']],
                ['Total Records', $stats['total_records']],
                ['Active Clearances (as of today)', $stats['active_clearances']],
                ['Total Animals Used', $stats['total_animals']],
            ] as [$label, $value]
        ) {
            $sheet->setCellValue("A$row", $label);
            $sheet->setCellValue("B$row", $value);
            $row++;
        }
        $row++;

        $row = $this->writeBreakdownTable($sheet, $row, 'Revisions per Protocol', $stats['revisions_by_protocol'], 'Protocol');
        $row = $this->writeBreakdownTable($sheet, $row, 'Revisions per PI', $stats['revisions_by_pi'], 'Principal Investigator');
        $row = $this->writeBreakdownTable($sheet, $row, 'Animals Used by Species', $stats['species_breakdown'], 'Species');
        $row = $this->writeBreakdownTable($sheet, $row, 'Protocols by School', $stats['school_breakdown'], 'School');
        $row = $this->writeBreakdownTable($sheet, $row, 'Protocols by Researcher Sex', $stats['sex_breakdown'], 'Researcher Sex');
        $row = $this->writeBreakdownTable($sheet, $row, 'Protocols by Researcher Type', $stats['researcher_type_breakdown'], 'Researcher Type');

        foreach (['A', 'B', 'C'] as $column) {
            $sheet->getColumnDimension($column)->setAutoSize(true);
        }
    }

    private function writeBreakdownTable(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet, int $row, string $title, array $breakdown, string $labelHeader): int
    {
        $sheet->setCellValue("A$row", $title);
        $sheet->getStyle("A$row")->getFont()->setBold(true);
        $row++;

        if (! $breakdown) {
            $sheet->setCellValue("A$row", 'No data.');
            return $row + 2;
        }

        $sheet->fromArray([$labelHeader, 'Count', '% of Total'], null, "A$row");
        $sheet->getStyle("A$row:C$row")->getFont()->setBold(true);
        $row++;

        $grandTotal = array_sum(array_column($breakdown, 'total'));
        foreach ($breakdown as $entry) {
            $pct = $grandTotal > 0 ? round(($entry['total'] / $grandTotal) * 100, 1) : 0;
            $sheet->fromArray([$entry['label'], (int) $entry['total'], "$pct%"], null, "A$row");
            $row++;
        }

        return $row + 1;
    }

    private function formatDurationRange(?string $start, ?string $end): string
    {
        if ($start && $end) {
            return date(DATE_FORMAT, strtotime($start)) . ' – ' . date(DATE_FORMAT, strtotime($end));
        }
        if ($start) {
            return 'From ' . date(DATE_FORMAT, strtotime($start));
        }
        if ($end) {
            return 'Until ' . date(DATE_FORMAT, strtotime($end));
        }
        return '';
    }

    // ===== RECORD INPUT CLEANUP =====
    private function sanitizeRecordPost(): array
    {
        $str = fn(string $k) => trim($_POST[$k] ?? '');
        return [
            'reference_no'            => $str('reference_no'),
            'ar_number'               => $str('ar_number'),
            'title_of_research'       => $str('title_of_research'),
            'school'                  => $str('school'),
            'animal_type'             => $str('animal_type'),
            'animal_count'            => $str('animal_count'),
            'principal_investigator'  => $str('principal_investigator'),
            'sex'                  => $str('sex'),
            'researcher_type'         => $str('researcher_type'),
            'research_adviser'        => $str('research_adviser'),
            'veterinarian'            => $str('veterinarian'),
            'research_duration_start' => $str('research_duration_start'),
            'research_duration_end'   => $str('research_duration_end'),
            'date_released'           => $str('date_released'),
            'received_by'             => $str('received_by'),
            'status'                  => in_array($str('status'), RecordModel::STATUSES, true) ? $str('status') : RecordModel::DEFAULT_STATUS,
        ];
    }

    // ===== ANNOUNCEMENTS PAGE =====
    public function announcements(): void
    {
        $this->requireStaff();
        $this->renderContentTab('announcements');
    }

    // ===== SITE CONTENT PAGE =====
    public function site_content(): void
    {
        $this->requireStaff();
        $this->renderContentTab('site_content');
    }

    private function renderContentTab(string $activeTab): void
    {
        $this->view('personnel/personnel-content', [
            'user'          => $_SESSION['user'],
            'csrf'          => $this->generateCsrfToken(),
            'announcements' => $this->announcementModel->getAll(),
            'settings'      => $this->settingsModel->getAll(),
            'offices'       => $this->officeModel->getAll(),
            'faqs'          => $this->faqModel->getAll(),
            'activeTab'     => $activeTab,
        ]);
    }

    // ===== SITE CONTENT: SETTINGS =====
    public function site_content_settings(): void
    {
        $this->requireStaff();
        $this->requirePostMethod();
        $this->verifyCsrfToken(true);

        $this->settingsModel->setMany([
            'banner_title'      => normalize_pasted_text(trim($_POST['banner_title'] ?? '')),
            'about_paragraph_1' => normalize_pasted_text(trim($_POST['about_paragraph_1'] ?? '')),
            'about_paragraph_2' => normalize_pasted_text(trim($_POST['about_paragraph_2'] ?? '')),
        ]);

        $actor = $this->actor();
        $this->settingsModel->logAudit('site_settings_updated', $actor['id'], $actor['name'], $actor['role'], 'site_settings', null, 'Updated homepage content');

        $_SESSION['flash_success'] = 'Homepage content updated.';
        $this->redirect('personnel/site_content');
    }

    // ===== SITE CONTENT: ADD OFFICE =====
    public function site_content_office_add(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $data = $this->sanitizeOfficePost();
        if ($data['name'] === '') {
            $this->jsonError(422, 'Office name is required.');
        }

        $ok = $this->officeModel->insert(
            $data['name'],
            null,
            $data['address'],
            $data['phone'],
            $data['email'],
            $data['facebook_url'],
            $data['facebook_label'],
            $data['website_url'],
            $data['website_label'],
            $data['director_name'],
            $data['director_role'],
            $data['director_email']
        );

        if ($ok) {
            $actor = $this->actor();
            $this->officeModel->logAudit('contact_office_added', $actor['id'], $actor['name'], $actor['role'], 'contact_office', null, "Contact office added: {$data['name']}");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Office added.' : 'Insert failed.']);
        exit;
    }

    // ===== SITE CONTENT: GET OFFICE =====
    public function site_content_office_get(): void
    {
        $this->requireStaff(true);
        header('Content-Type: application/json');

        $id  = (int) ($_GET['id'] ?? 0);
        $row = $id > 0 ? $this->officeModel->getById($id) : null;

        echo json_encode(
            $row
                ? ['ok' => true, 'data' => $row]
                : ['ok' => false, 'message' => 'Office not found.']
        );
        exit;
    }

    // ===== SITE CONTENT: EDIT OFFICE =====
    public function site_content_office_edit(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $id = (int) ($_POST['id'] ?? 0);
        if ($id <= 0 || ! $this->officeModel->getById($id)) {
            $this->jsonError(404, 'Office not found.');
        }

        $data = $this->sanitizeOfficePost();
        if ($data['name'] === '') {
            $this->jsonError(422, 'Office name is required.');
        }

        $ok = $this->officeModel->update(
            $id,
            $data['name'],
            $data['address'],
            $data['phone'],
            $data['email'],
            $data['facebook_url'],
            $data['facebook_label'],
            $data['website_url'],
            $data['website_label'],
            $data['director_name'],
            $data['director_role'],
            $data['director_email']
        );

        if ($ok) {
            $actor = $this->actor();
            $this->officeModel->logAudit('contact_office_edited', $actor['id'], $actor['name'], $actor['role'], 'contact_office', $id, "Contact office edited: {$data['name']}");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Office updated.' : 'Update failed.']);
        exit;
    }

    // ===== SITE CONTENT: MOVE OFFICE =====
    public function site_content_office_move(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $id        = (int) ($_POST['id'] ?? 0);
        $direction = $_POST['direction'] ?? '';
        $office    = $id > 0 ? $this->officeModel->getById($id) : null;

        if (! $office || ! in_array($direction, ['up', 'down'], true)) {
            $this->jsonError(404, 'Office not found.');
        }

        $ok = $this->officeModel->move($id, $direction);

        if ($ok) {
            $actor = $this->actor();
            $this->officeModel->logAudit('contact_office_moved', $actor['id'], $actor['name'], $actor['role'], 'contact_office', $id, "Contact office moved {$direction}: {$office['name']}");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Office moved.' : 'Move failed.']);
        exit;
    }

    // ===== SITE CONTENT: DELETE OFFICE =====
    public function site_content_office_delete(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $id     = (int) ($_POST['id'] ?? 0);
        $office = $id > 0 ? $this->officeModel->getById($id) : null;
        $ok     = $office ? $this->officeModel->delete($id) : false;

        if ($ok) {
            $actor = $this->actor();
            $this->officeModel->logAudit('contact_office_deleted', $actor['id'], $actor['name'], $actor['role'], 'contact_office', $id, "Contact office deleted: {$office['name']}");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Office deleted.' : 'Delete failed.']);
        exit;
    }

    // ===== OFFICE INPUT CLEANUP =====
    private function sanitizeOfficePost(): array
    {
        $facebookUrl = trim($_POST['facebook_url'] ?? '');
        $websiteUrl  = trim($_POST['website_url'] ?? '');

        foreach ([$facebookUrl, $websiteUrl] as $url) {
            if ($url !== '' && ! preg_match('#^https?://#i', $url)) {
                $this->jsonError(422, 'Facebook and Website URLs must start with http:// or https://');
            }
        }

        return [
            'name'           => normalize_pasted_text(trim($_POST['name'] ?? '')),
            'address'        => normalize_pasted_text(trim($_POST['address'] ?? '')) ?: null,
            'phone'          => normalize_pasted_text(trim($_POST['phone'] ?? '')) ?: null,
            'email'          => normalize_pasted_text(trim($_POST['email'] ?? '')) ?: null,
            'facebook_url'   => $facebookUrl ?: null,
            'facebook_label' => normalize_pasted_text(trim($_POST['facebook_label'] ?? '')) ?: null,
            'website_url'    => $websiteUrl ?: null,
            'website_label'  => normalize_pasted_text(trim($_POST['website_label'] ?? '')) ?: null,
            'director_name'  => normalize_pasted_text(trim($_POST['director_name'] ?? '')) ?: null,
            'director_role'  => normalize_pasted_text(trim($_POST['director_role'] ?? '')) ?: null,
            'director_email' => trim($_POST['director_email'] ?? '') ?: null,
        ];
    }

    // ===== SITE CONTENT: ADD FAQ =====
    public function site_content_faq_add(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $data = $this->sanitizeFaqPost();
        if ($data['question'] === '' || $data['answer'] === '') {
            $this->jsonError(422, 'Both a question and an answer are required.');
        }

        $ok = $this->faqModel->insert($data['sort_order'], $data['question'], $data['answer']);

        if ($ok) {
            $actor = $this->actor();
            $this->faqModel->logAudit('faq_added', $actor['id'], $actor['name'], $actor['role'], 'faq', null, "FAQ added: {$data['question']}");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'FAQ added.' : 'Insert failed.']);
        exit;
    }

    // ===== SITE CONTENT: GET FAQ =====
    public function site_content_faq_get(): void
    {
        $this->requireStaff(true);
        header('Content-Type: application/json');

        $id  = (int) ($_GET['id'] ?? 0);
        $row = $id > 0 ? $this->faqModel->getById($id) : null;

        echo json_encode(
            $row
                ? ['ok' => true, 'data' => $row]
                : ['ok' => false, 'message' => 'FAQ not found.']
        );
        exit;
    }

    // ===== SITE CONTENT: EDIT FAQ =====
    public function site_content_faq_edit(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $id = (int) ($_POST['id'] ?? 0);
        if ($id <= 0 || ! $this->faqModel->getById($id)) {
            $this->jsonError(404, 'FAQ not found.');
        }

        $data = $this->sanitizeFaqPost();
        if ($data['question'] === '' || $data['answer'] === '') {
            $this->jsonError(422, 'Both a question and an answer are required.');
        }

        $ok = $this->faqModel->update($id, $data['sort_order'], $data['question'], $data['answer']);

        if ($ok) {
            $actor = $this->actor();
            $this->faqModel->logAudit('faq_edited', $actor['id'], $actor['name'], $actor['role'], 'faq', $id, "FAQ edited: {$data['question']}");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'FAQ updated.' : 'Update failed.']);
        exit;
    }

    // ===== SITE CONTENT: DELETE FAQ =====
    public function site_content_faq_delete(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $id  = (int) ($_POST['id'] ?? 0);
        $faq = $id > 0 ? $this->faqModel->getById($id) : null;
        $ok  = $faq ? $this->faqModel->delete($id) : false;

        if ($ok) {
            $actor = $this->actor();
            $this->faqModel->logAudit('faq_deleted', $actor['id'], $actor['name'], $actor['role'], 'faq', $id, "FAQ deleted: {$faq['question']}");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'FAQ deleted.' : 'Delete failed.']);
        exit;
    }

    // ===== FAQ INPUT CLEANUP =====
    private function sanitizeFaqPost(): array
    {
        return [
            'sort_order' => (int) ($_POST['sort_order'] ?? 0),
            'question'   => normalize_pasted_text(trim($_POST['question'] ?? '')),
            'answer'     => normalize_pasted_text(trim($_POST['answer'] ?? '')),
        ];
    }

    // ===== ACCOUNTS PAGE =====
    public function accounts(): void
    {
        $this->requireStaff();

        $auditDateRange = $this->userModel->getAuditLogDateRange();

        $today       = date('Y-m-d');
        $ninetyAgo   = date('Y-m-d', strtotime('-90 days'));
        $defaultTo   = $auditDateRange['latest'] ? min($today, $auditDateRange['latest']) : $today;
        $defaultFrom = $auditDateRange['earliest'] ? max($ninetyAgo, $auditDateRange['earliest']) : $ninetyAgo;
        $defaultFrom = min($defaultFrom, $defaultTo);

        $auditFilterDate = $this->sanitizeDate($_GET['audit_date'] ?? '');
        $requestedPage   = (int) ($_GET['audit_page'] ?? 1);
        $auditLogPage    = $this->fetchAuditLogPage($requestedPage, $auditFilterDate);

        $this->view('personnel/personnel-accounts', array_merge([
            'user'           => $_SESSION['user'],
            'csrf'           => $this->generateCsrfToken(),
            'pending'        => $this->userModel->getPendingUsers(),
            'personnel'      => $this->userModel->getPersonnelAccounts(),
            'auditDateRange' => $auditDateRange,
            'auditDefaults'  => ['from' => $defaultFrom, 'to' => $defaultTo],
        ], $auditLogPage));
    }

    // ===== AUDIT LOG VIEWER (AJAX) =====
    public function auditLogResults(): void
    {
        $this->requireStaff(true);

        $auditFilterDate = $this->sanitizeDate($_GET['audit_date'] ?? '');
        $requestedPage   = (int) ($_GET['audit_page'] ?? 1);
        $auditLogPage    = $this->fetchAuditLogPage($requestedPage, $auditFilterDate);

        ob_start();
        extract($auditLogPage);
        include dirname(__DIR__) . '/views/personnel/partials/audit-log-results.view.php';
        $html = ob_get_clean();

        header('Content-Type: application/json');
        echo json_encode([
            'ok'    => true,
            'html'  => $html,
            'page'  => $auditLogPage['auditPage'],
            'pages' => $auditLogPage['auditPages'],
            'total' => $auditLogPage['auditTotal'],
        ]);
        exit;
    }

    private function fetchAuditLogPage(int $requestedPage, ?string $filterDate): array
    {
        $auditPerPage = 6;
        $fromDate     = $filterDate;
        $toDate       = $filterDate;

        $auditTotal = $this->userModel->countAuditLogs($fromDate, $toDate);
        $auditPages = max(1, (int) ceil($auditTotal / $auditPerPage));
        $auditPage  = min(max(1, $requestedPage), $auditPages);
        $auditLogs  = $this->userModel->getAuditLogs($fromDate, $toDate, $auditPerPage, ($auditPage - 1) * $auditPerPage);

        $targetNameCache = [];
        foreach ($auditLogs as &$log) {
            $log['action_label'] = $this->humanizeAuditAction($log['action']);
            $log['target_label'] = $this->resolveAuditTargetName($log['target_type'], $log['target_id'], $targetNameCache);
        }
        unset($log);

        return [
            'auditLogs'       => $auditLogs,
            'auditPage'       => $auditPage,
            'auditPages'      => $auditPages,
            'auditTotal'      => $auditTotal,
            'auditPerPage'    => $auditPerPage,
            'auditOffset'     => ($auditPage - 1) * $auditPerPage,
            'auditFilterDate' => $filterDate,
        ];
    }

    // ===== AUDIT LOG DOWNLOAD (XLSX) =====
    public function downloadAuditLogs(): void
    {
        $this->requireStaff();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('personnel/accounts');
        }

        $this->verifyCsrfToken(false);

        $fullHistory = ($_POST['full_history'] ?? '') === '1';

        if ($fullHistory) {
            $fromDate = null;
            $toDate   = null;
        } else {
            $fromDate = $this->sanitizeDate($_POST['from_date'] ?? '');
            $toDate   = $this->sanitizeDate($_POST['to_date'] ?? '');

            if ($fromDate === null || $toDate === null) {
                $_SESSION['flash_error'] = 'Please select both a from and to date, or choose to export the full history.';
                $this->redirect('personnel/accounts');
            }
        }

        $actor = $this->actor();
        $logs  = $this->userModel->getAuditLogs($fromDate, $toDate);

        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Audit Logs');

        $headers = ['Timestamp', 'Username', 'Role', 'Action', 'Target', 'Details', 'IP Address'];
        $sheet->fromArray($headers, null, 'A1');

        $targetNameCache = [];

        $row = 2;
        foreach ($logs as $log) {
            $sheet->fromArray([
                $log['created_at'],
                $log['username'],
                ucfirst($log['role']),
                $this->humanizeAuditAction($log['action']),
                $this->resolveAuditTargetName($log['target_type'], $log['target_id'], $targetNameCache),
                $log['details'],
                $log['ip_address'],
            ], null, "A$row");
            $row++;
        }

        foreach (range('A', 'G') as $column) {
            $sheet->getColumnDimension($column)->setAutoSize(true);
        }

        $rangeDescription = $fullHistory
            ? 'Exported audit logs to Excel (full history)'
            : "Exported audit logs to Excel ({$fromDate} to {$toDate})";

        $this->userModel->logAudit(
            'audit_logs_exported',
            $actor['id'],
            $actor['name'],
            $actor['role'],
            'audit_logs',
            null,
            $rangeDescription
        );

        $filename = 'audit-logs-' . date('Y-m-d_His') . '.xlsx';

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');

        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }

    // ===== AUDIT LOG HELPERS =====
    private function sanitizeDate(string $date): ?string
    {
        if ($date === '') {
            return null;
        }

        $parsed = \DateTime::createFromFormat('Y-m-d', $date);
        return ($parsed && $parsed->format('Y-m-d') === $date) ? $date : null;
    }

    private function humanizeAuditAction(string $action): string
    {
        return ucwords(str_replace('_', ' ', $action));
    }

    private function resolveAuditTargetName(?string $targetType, ?int $targetId, array &$cache): string
    {
        if (empty($targetType)) {
            return '';
        }

        $typeLabel = ucwords(str_replace('_', ' ', $targetType));

        if ($targetId === null) {
            return $typeLabel;
        }

        $cacheKey = "$targetType:$targetId";
        if (array_key_exists($cacheKey, $cache)) {
            return $cache[$cacheKey];
        }

        $lookupSupported = in_array($targetType, ['user', 'protocol', 'record', 'announcement'], true);

        $name = match ($targetType) {
            'user' => $this->userDisplayName($targetId),
            'protocol' => $this->protocolDisplayName($targetId),
            'record' => $this->recordDisplayName($this->recordModel->getById($targetId)),
            'announcement' => $this->announcementDisplayName($targetId),
            default => null,
        };

        if ($name !== null && $name !== '') {
            $result = "$typeLabel: $name";
        } elseif ($lookupSupported) {
            $result = "$typeLabel #$targetId (no longer exists)";
        } else {
            $result = "$typeLabel #$targetId";
        }

        $cache[$cacheKey] = $result;
        return $result;
    }

    private function recordDisplayName(?array $record): ?string
    {
        if (!$record) {
            return null;
        }
        return $record['reference_no'] !== '' ? "IPN {$record['reference_no']}" : ($record['title_of_research'] ?? null);
    }

    private function announcementDisplayName(int $id): ?string
    {
        $announcement = $this->announcementModel->getById($id);
        return $announcement['title'] ?? null;
    }

    private function userDisplayName(int $id): ?string
    {
        $user = $this->userModel->getUser($id);
        return $user['username'] ?? null;
    }

    private function protocolDisplayName(int $id): ?string
    {
        $protocol = $this->protocolModel->getById($id);
        return $protocol['research_title'] ?? null;
    }

    // ===== STAFF LOG IN =====
    public function login(): void
    {
        if ($this->isLoggedIn()) {
            $role = $_SESSION['user']['role'] ?? '';
            $this->redirect(in_array($role, ['staff', 'reviewer']) ? 'personnel/home' : 'submissions');
        }

        $this->view('personnel/personnel-login', [
            'csrf'  => $this->generateCsrfToken(),
            'error' => $_SESSION['flash_error'] ?? '',
        ]);
        unset($_SESSION['flash_error']);
    }

    public function login_process(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('personnel/login');
        }

        $this->verifyCsrfToken(true);

        $input    = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $ip       = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

        $MAX_ATTEMPTS = 5;
        $WINDOW       = 900;

        if (
            $this->userModel->countRecentAttempts($ip, $WINDOW) >= $MAX_ATTEMPTS
            || $this->userModel->countRecentAttempts($input, $WINDOW) >= $MAX_ATTEMPTS
        ) {
            $this->userModel->logAudit('login_locked', null, $input, '', 'user', null, 'Login temporarily locked after repeated failed attempts');
            $_SESSION['flash_error'] = 'Too many failed login attempts. Please wait 15 minutes before trying again.';
            $this->redirect('personnel/login');
        }

        if (empty($input) || empty($password)) {
            $_SESSION['flash_error'] = 'Please fill in all fields.';
            $this->redirect('personnel/login');
        }

        $user = $this->userModel->getUserByUsername($input) ?? $this->userModel->getUserByEmail($input);

        if (!$user) {
            $this->userModel->recordLoginAttempt($ip);
            $this->userModel->recordLoginAttempt($input);
            $this->userModel->logAudit('login_failed', null, $input, '', '', null, 'Failed personnel login attempt');
            $_SESSION['flash_error'] = 'No account found with that username or email.';
            $this->redirect('personnel/login');
        }

        if (!in_array($user['role'], ['staff', 'reviewer'])) {
            $_SESSION['flash_error'] = 'This portal is for CCARD personnel only.';
            $this->redirect('personnel/login');
        }

        if (($user['status'] ?? 'active') === 'pending') {
            $_SESSION['flash_error'] = 'Your account is pending administrative staff approval.';
            $this->redirect('personnel/login');
        }

        if (!password_verify($password, $user['password'])) {
            $this->userModel->recordLoginAttempt($ip);
            $this->userModel->recordLoginAttempt($input);
            $this->userModel->logAudit('login_failed', null, $input, '', '', null, 'Failed personnel login attempt');
            $_SESSION['flash_error'] = 'Invalid password. Please try again.';
            $this->redirect('personnel/login');
        }

        $this->userModel->clearLoginAttempts($ip);
        $this->userModel->clearLoginAttempts($input);

        session_regenerate_id(true);
        $_SESSION['user'] = [
            'user_id'        => $user['id'],
            'first_name'     => $user['first_name'],
            'username'       => $user['username'],
            'role'           => $user['role'],
            'email_verified' => (bool) $user['email_verified'],
        ];

        if (empty($user['welcome_seen'])) {
            $_SESSION['user']['show_welcome'] = true;
            $this->userModel->markWelcomeSeen((int) $user['id']);
        }

        $this->userModel->logAudit('login_success', (int) $user['id'], $user['username'], $user['role'], 'user', (int) $user['id'], 'Personnel logged in');
        $this->redirect('personnel/home');
    }

    // ===== STAFF LOG OUT =====
    public function logout(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('personnel/home');
        }

        $actor = $this->actor();
        $this->userModel->logAudit('logout', $actor['id'], $actor['name'], $actor['role'], 'user', $actor['id'], 'Personnel logged out');

        session_destroy();
        session_start();
        $this->redirect('personnel/login');
    }

    // ===== STAFF REGISTRATION (INVITE ONLY) =====
    private function getValidInvite(string $token): array
    {
        $invite = $this->userModel->getValidInviteToken($token);
        if (!$invite) {
            $this->renderError(403, 'Invalid Invite Link', [
                'This invite link is invalid or has expired.',
                'Please contact an administrator to request a new one.',
            ]);
        }
        return $invite;
    }

    public function register(): void
    {
        $token  = $_GET['token'] ?? '';
        $invite = $this->getValidInvite($token);

        $this->view('personnel/personnel-register', [
            'csrf'        => $this->generateCsrfToken(),
            'token'       => htmlspecialchars($token),
            'preset_role' => $invite['role'],
            'errors'      => [],
            'old'         => [],
        ]);
    }

    public function register_process(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('personnel/login');
        }

        $this->verifyCsrfToken();

        $token  = $_POST['invite_token'] ?? '';
        $invite = $this->getValidInvite($token);
        $role   = $invite['role'];

        $username     = trim(preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['username'] ?? ''));
        $first_name   = ucfirst(mb_strtolower(trim(preg_replace('/[^\p{L}\p{M}\s\-\']/u', '', $_POST['first_name'] ?? ''))));
        $last_name    = trim(preg_replace('/[^\p{L}\p{M}\s\-\']/u', '', $_POST['last_name'] ?? ''));
        $email        = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
        $sex          = in_array($_POST['sex'] ?? '', ['Male', 'Female'], true) ? $_POST['sex'] : '';
        $password     = $_POST['password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        $old    = compact('username', 'first_name', 'last_name', 'email', 'sex', 'role');
        $errors = [];

        if (empty($sex)) {
            $errors[] = 'Please select your sex.';
        }

        if (empty($username) || strlen($username) < 3 || strlen($username) > 50) {
            $errors[] = 'Username must be 3-50 characters (letters, numbers, _ or -).';
        }
        if (empty($first_name) || strlen($first_name) < 2) {
            $errors[] = 'First name must be at least 2 characters.';
        }
        if (empty($last_name) || strlen($last_name) < 2) {
            $errors[] = 'Last name must be at least 2 characters.';
        }
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'A valid email address is required.';
        }

        $pw_reqs = $this->validatePasswordRequirements($password);
        if (!empty($pw_reqs)) {
            $errors[] = 'Password must contain: ' . implode(', ', $pw_reqs) . '.';
        }
        if ($password !== $confirm_pass) {
            $errors[] = 'Passwords do not match.';
        }

        if (empty($errors)) {
            $existing = $this->userModel->getUserByEmail($email);
            if ($existing) {
                $errors[] = $existing['role'] === 'researcher'
                    ? 'This email belongs to a researcher account. Please use a different email, or delete your researcher account first.'
                    : 'That email is already taken.';
            }
            if ($this->userModel->getUserByUsername($username)) {
                $errors[] = 'That username is already taken.';
            }
        }

        if (!empty($errors)) {
            $this->view('personnel/personnel-register', [
                'csrf'        => $this->generateCsrfToken(),
                'token'       => htmlspecialchars($token),
                'preset_role' => $role,
                'errors'      => $errors,
                'old'         => $old,
            ]);
            return;
        }

        $ok = $this->userModel->insertUser($username, $first_name, $last_name, $email, password_hash($password, PASSWORD_DEFAULT), $role, 'pending', null, null, $sex);

        if ($ok) {
            $newUserId = $this->userModel->connection->insert_id;
            $this->userModel->consumeInviteToken($token, $newUserId);
            Mailer::sendTemplate('application_received', ['first_name' => $first_name, 'role' => $role], $email, $first_name, 'Application Received');
            $this->view('personnel/personnel-register', [
                'csrf'    => $this->generateCsrfToken(),
                'token'   => htmlspecialchars($token),
                'errors'  => [],
                'old'     => [],
                'success' => true,
            ]);
        } else {
            $this->view('personnel/personnel-register', [
                'csrf'        => $this->generateCsrfToken(),
                'token'       => htmlspecialchars($token),
                'preset_role' => $role,
                'errors'      => ['Registration failed. Please try again.'],
                'old'         => $old,
            ]);
        }
    }

    // ===== GENERATE INVITE =====
    public function generate_invite(): void
    {
        $this->requireStaff();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('personnel/accounts?tab=accounts');
        }

        $this->verifyCsrfToken();

        $role = $_POST['invite_role'] ?? 'staff';
        if (!in_array($role, ['staff', 'reviewer'])) {
            $role = 'staff';
        }

        $token = $this->userModel->createInviteToken($role, 48);

        $actor = $this->actor();
        $this->userModel->logAudit('invite_generated', $actor['id'], $actor['name'], $actor['role'], 'invite', null, "Generated invite link for role: $role");

        $this->view('personnel/personnel-accounts', [
            'user'        => $_SESSION['user'],
            'csrf'        => $this->generateCsrfToken(),
            'invite_url'  => ROOT . '/personnel/register?token=' . $token,
            'invite_role' => $role,
        ]);
    }

    // ===== APPROVE ACCOUNT =====
    public function approve(): void
    {
        $this->requireStaff();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('personnel/accounts?tab=accounts');
        }

        $this->verifyCsrfToken();

        $id = (int) ($_POST['user_id'] ?? 0);
        if ($id > 0) {
            $applicant = $this->userModel->getUser($id);
            $actor     = $this->actor();

            $this->userModel->logAudit('user_approved', $actor['id'], $actor['name'], $actor['role'], 'user', $id, 'Approved personnel account: ' . ($applicant['username'] ?? $id));
            $this->userModel->approveUser($id);

            if ($applicant) {
                Notifier::send(
                    $id,
                    'account_verified',
                    'Account Verified',
                    'Your account has been verified. You can now log in.',
                    'user/account',
                    [
                        'template' => 'application_approved',
                        'vars'     => ['first_name' => $applicant['first_name']],
                        'to'       => $applicant['email'],
                        'name'     => $applicant['first_name'],
                        'subject'  => 'Application Approved',
                    ]
                );
            }
        }

        $_SESSION['flash_success'] = 'Account approved.';
        $this->redirect('personnel/accounts?tab=accounts');
    }

    // ===== REJECT ACCOUNT =====
    public function reject(): void
    {
        $this->requireStaff();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('personnel/accounts?tab=accounts');
        }

        $this->verifyCsrfToken();

        $id = (int) ($_POST['user_id'] ?? 0);
        if ($id > 0) {
            $applicant = $this->userModel->getUser($id);
            $actor     = $this->actor();

            $this->userModel->logAudit('user_rejected', $actor['id'], $actor['name'], $actor['role'], 'user', $id, 'Rejected personnel account: ' . ($applicant['username'] ?? $id));
            $this->userModel->rejectUser($id);

            if ($applicant) {
                Mailer::sendTemplate('application_rejected', ['first_name' => $applicant['first_name']], $applicant['email'], $applicant['first_name'], 'Application Update');
            }
        }

        $_SESSION['flash_success'] = 'Account rejected and removed.';
        $this->redirect('personnel/accounts?tab=accounts');
    }

    // ===== CHANGE ROLE =====
    public function update_role(): void
    {
        $this->requireStaff();

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('personnel/accounts?tab=accounts');
        }

        $this->verifyCsrfToken();

        $id       = (int) ($_POST['user_id'] ?? 0);
        $role     = $_POST['role'] ?? '';
        $password = $_POST['password'] ?? '';
        $actor    = $this->actor();

        if ($this->isActor($id)) {
            $_SESSION['flash_error'] = 'You cannot change your own role.';
            $this->redirect('personnel/accounts?tab=accounts');
        }

        if (!in_array($role, ['staff', 'reviewer'], true)) {
            $_SESSION['flash_error'] = 'Invalid role selected.';
            $this->redirect('personnel/accounts?tab=accounts');
        }

        $actorRecord = $this->userModel->getUser($actor['id']);
        if (empty($password) || !$actorRecord || !password_verify($password, $actorRecord['password'])) {
            $this->userModel->logAudit('user_role_change_denied', $actor['id'], $actor['name'], $actor['role'], 'user', $id, 'Incorrect password entered while attempting a role change');
            $_SESSION['flash_error'] = 'Incorrect password. Role not changed.';
            $this->redirect('personnel/accounts?tab=accounts');
        }

        $target = $this->userModel->getUser($id);
        if ($target && in_array($target['role'], ['staff', 'reviewer'], true)) {
            $this->userModel->updateUserRole($id, $role);
            $this->userModel->logAudit('user_role_changed', $actor['id'], $actor['name'], $actor['role'], 'user', $id, "Changed role for {$target['username']} from {$target['role']} to $role");
            $_SESSION['flash_success'] = 'Role updated to ' . ucfirst($role) . '.';
        } else {
            $_SESSION['flash_error'] = 'Personnel account not found.';
        }

        $this->redirect('personnel/accounts?tab=accounts');
    }

    // ===== FORGOT / RESET PASSWORD =====
    public function forgot_password(): void
    {
        $this->handleForgotPassword('personnel/forgot_password', 'personnel/reset_password', 'personnel/login');
    }

    public function reset_password(): void
    {
        $this->handleResetPassword('personnel/reset_password', 'personnel/login');
    }

    // ===== ANNOUNCEMENT IMAGE HELPERS =====
    private function announcementImageDir(): string
    {
        return dirname(__DIR__, 2) . '/portal/assets/uploads/announcements/';
    }

    private function saveAnnouncementImage(string $inputName, ?string &$reason = null): string|false|null
    {
        if (empty($_FILES[$inputName]['tmp_name']) || $_FILES[$inputName]['error'] !== UPLOAD_ERR_OK) {
            return null;
        }

        $file = $_FILES[$inputName];

        if ($file['size'] > 5 * 1024 * 1024) {
            $reason = 'That image is larger than the 5 MB limit.';
            return false;
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowedExts = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        if (!in_array($ext, $allowedExts, true)) {
            $reason = 'Please upload a JPG, PNG, WEBP, or GIF image.';
            return false;
        }

        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime  = $finfo->file($file['tmp_name']);
        $mimeMap = [
            'jpg'  => ['image/jpeg', 'image/pjpeg'],
            'jpeg' => ['image/jpeg', 'image/pjpeg'],
            'png'  => ['image/png', 'image/x-png'],
            'webp' => ['image/webp'],
            'gif'  => ['image/gif'],
        ];
        if (!in_array($mime, $mimeMap[$ext], true)) {
            $reason = 'That file doesn\'t look like a real image (its content doesn\'t match a "' . $ext . '" file). Please re-save or export it and try again.';
            return false;
        }

        $dir = $this->announcementImageDir();
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        $webpName = $this->saveAsWebp($file['tmp_name'], $ext, $dir);
        if ($webpName !== null) {
            return $webpName;
        }

        $safeName = bin2hex(random_bytes(8)) . '.' . $ext;

        if (!move_uploaded_file($file['tmp_name'], $dir . $safeName)) {
            $reason = 'Could not save the uploaded image. Please try again.';
            return false;
        }

        return $safeName;
    }

    private function saveAsWebp(string $tmpPath, string $ext, string $dir): ?string
    {
        if (!function_exists('imagewebp') || !extension_loaded('gd')) {
            return null;
        }

        $image = match ($ext) {
            'jpg', 'jpeg' => @imagecreatefromjpeg($tmpPath),
            'png'         => @imagecreatefrompng($tmpPath),
            'gif'         => @imagecreatefromgif($tmpPath),
            'webp'        => @imagecreatefromwebp($tmpPath),
            default       => null,
        };

        if (!$image) {
            return null;
        }

        if ($ext === 'png' || $ext === 'gif') {
            imagepalettetotruecolor($image);
            imagealphablending($image, true);
            imagesavealpha($image, true);
        }

        $safeName = bin2hex(random_bytes(8)) . '.webp';
        $saved    = imagewebp($image, $dir . $safeName, 82);
        imagedestroy($image);

        return $saved ? $safeName : null;
    }

    private function deleteAnnouncementImage(?string $filename): void
    {
        if (!$filename) return;
        $path = $this->announcementImageDir() . $filename;
        if (is_file($path)) {
            @unlink($path);
        }
    }

    // ===== ANNOUNCEMENTS: ADD =====
    public function announcements_add(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $title = normalize_pasted_text(trim($_POST['title'] ?? ''));
        $body  = normalize_pasted_text(trim($_POST['body'] ?? ''));

        $imageReason = null;
        $imageName   = $this->saveAnnouncementImage('image', $imageReason);
        if ($imageName === false) {
            $this->jsonError(422, $imageReason ?: 'Image upload failed.');
        }

        if ($body === '' && $imageName === null) {
            $this->jsonError(422, 'Add either content or an image.');
        }

        $actor = $this->actor();
        $ok    = $this->announcementModel->insert($title, $body, $imageName, $actor['id'] ?: null);

        if ($ok) {
            $this->announcementModel->logAudit('announcement_added', $actor['id'], $actor['name'], $actor['role'], 'announcement', null, "Announcement added: $title");
        } elseif ($imageName) {

            $this->deleteAnnouncementImage($imageName);
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Announcement added.' : 'Insert failed.']);
        exit;
    }

    // ===== ANNOUNCEMENTS: GET =====
    public function announcements_get(): void
    {
        $this->requireStaff(true);
        header('Content-Type: application/json');

        $id  = (int) ($_GET['id'] ?? 0);
        $row = $id > 0 ? $this->announcementModel->getById($id) : null;

        echo json_encode(
            $row
                ? ['ok' => true, 'data' => $row]
                : ['ok' => false, 'message' => 'Announcement not found.']
        );
        exit;
    }

    // ===== ANNOUNCEMENTS: EDIT =====
    public function announcements_edit(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $id    = (int) ($_POST['id'] ?? 0);
        $title = normalize_pasted_text(trim($_POST['title'] ?? ''));
        $body  = normalize_pasted_text(trim($_POST['body'] ?? ''));

        $existing = $id > 0 ? $this->announcementModel->getById($id) : null;
        if (!$existing) {
            $this->jsonError(404, 'Announcement not found.');
        }

        $imageReason = null;
        $newImage    = $this->saveAnnouncementImage('image', $imageReason);
        if ($newImage === false) {
            $this->jsonError(422, $imageReason ?: 'Image upload failed.');
        }

        $removeImage = ($_POST['remove_image'] ?? '') === '1';

        if ($newImage !== null) {
            $imageToSave = $newImage;
        } elseif ($removeImage) {
            $imageToSave = null;
        } else {
            $imageToSave = 'KEEP';
        }

        $hasImage = $imageToSave === 'KEEP' ? !empty($existing['image_path']) : $imageToSave !== null;
        if ($body === '' && !$hasImage) {
            $this->jsonError(422, 'Add either content or an image.');
        }

        if ($newImage !== null || $removeImage) {
            $this->deleteAnnouncementImage($existing['image_path']);
        }

        $ok = $this->announcementModel->update($id, $title, $body, $imageToSave);

        if ($ok) {
            $actor = $this->actor();
            $this->announcementModel->logAudit('announcement_edited', $actor['id'], $actor['name'], $actor['role'], 'announcement', $id, "Announcement edited: $title");
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Announcement updated.' : 'Update failed.']);
        exit;
    }

    // ===== ANNOUNCEMENTS: DELETE =====
    public function announcements_delete(): void
    {
        $this->requireStaff(true);
        $this->requirePostMethod();
        $this->verifyCsrfToken(false);
        header('Content-Type: application/json');

        $id = (int) ($_POST['id'] ?? 0);
        if ($id < 1) {
            $this->jsonError(400, 'No announcement id given.');
        }

        $existing = $this->announcementModel->getById($id);

        $ok = $this->announcementModel->delete($id);

        if ($ok) {
            $actor = $this->actor();
            $this->announcementModel->logAudit('announcement_deleted', $actor['id'], $actor['name'], $actor['role'], 'announcement', $id, "Announcement deleted: #$id");
            if ($existing) {
                $this->deleteAnnouncementImage($existing['image_path']);
            }
        }

        echo json_encode(['ok' => $ok, 'message' => $ok ? 'Announcement deleted.' : 'Delete failed.']);
        exit;
    }
}
