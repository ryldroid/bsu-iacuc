<?php

/** @var array|null $user */
$role = $user['role'] ?? '';
$previewMode = $previewMode ?? false;
$pubRoot     = $pubRoot ?? ($previewMode ? ROOT . '/preview' : ROOT);
?>

<link rel="stylesheet" href="<?= asset_css('navigation.css') ?>">

<aside>
    <nav aria-label="Main navigation" class="main-navigation">
        <ul>

            <!-- PERSONNEL (STAFF / REVIEWER) NAVIGATION -->
            <?php if ($role === 'staff' || $role === 'reviewer'): ?>
                <li>
                    <a href="<?= ROOT ?>/personnel/home">
                        <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                            <use href="#dashboard-icon" />
                        </svg>
                    </a>
                    <div>
                        <span>Dashboard</span>
                    </div>
                </li>

                <?php if ($role === 'staff'): ?>
                    <!-- STAFF ONLY -->
                    <li>
                        <a href="<?= ROOT ?>/personnel/records">
                            <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <use href="#protocols-icon" />
                            </svg>
                        </a>
                        <div>
                            <span>Records</span>
                        </div>
                    </li>

                    <li>
                        <a href="<?= ROOT ?>/personnel/announcements">
                            <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <use href="#edit-icon" />
                            </svg>
                        </a>
                        <div>
                            <span>Site Content</span>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if ($role === 'reviewer'): ?>
                    <!-- REVIEWER ONLY -->
                    <li>
                        <a href="<?= ROOT ?>/personnel/records">
                            <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <use href="#protocols-icon" />
                            </svg>
                        </a>
                        <div>
                            <span>Records</span>
                        </div>
                    </li>
                <?php endif; ?>


                <?php if ($role === 'staff'): ?>
                    <li>
                        <a href="<?= ROOT ?>/personnel/accounts">
                            <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <use href="#accounts-icon" />
                            </svg>
                        </a>
                        <div>
                            <span>Administration</span>
                        </div>
                    </li>
                <?php endif; ?>

            <?php else: ?>
                <!-- PUBLIC / RESEARCHER NAVIGATION -->
                <li>
                    <a href="<?= $pubRoot ?>/home">
                        <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                            <use href="#home-icon" />
                        </svg>
                    </a>
                    <div>
                        <span>Home</span>
                    </div>
                </li>

                <?php if ($role === 'researcher'): ?>
                    <!-- RESEARCHER ONLY -->
                    <li>
                        <a href="<?= ROOT ?>/submissions">
                            <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                                <use href="#protocols-icon" />
                            </svg>
                        </a>
                        <div>
                            <span>My Protocols</span>
                        </div>
                    </li>
                <?php endif; ?>

                <li>
                    <a href="<?= $pubRoot ?>/announcements">
                        <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                            <use href="#announcement-icon" />
                        </svg>
                    </a>
                    <div>
                        <span>Announcements</span>
                    </div>
                </li>

                <li>
                    <a href="<?= $pubRoot ?>/contact">
                        <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                            <use href="#contact-icon" />
                        </svg>
                    </a>
                    <div>
                        <span>Contact Us</span>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</aside>