<?php

class UserModel extends Model
{
  public $table = 'users';

  // ===== GETTING USERS =====

  public function getUserByEmail($email)
  {
    $stmt = $this->connection->prepare("SELECT * FROM $this->table WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
  }

  public function getUserByUsername($username)
  {
    $stmt = $this->connection->prepare("SELECT * FROM $this->table WHERE username = ?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
  }

  public function getUser($id)
  {
    $stmt = $this->connection->prepare("SELECT * FROM $this->table WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
  }

  // ===== AUDIT LOGS =====

  public function getAuditLogDateRange(): array
  {
    $result = $this->connection->query(
      "SELECT MIN(DATE(created_at)) AS earliest, MAX(DATE(created_at)) AS latest FROM audit_logs"
    );
    return $result->fetch_assoc() ?: ['earliest' => null, 'latest' => null];
  }

  private function buildAuditLogFilters(?string $fromDate, ?string $toDate): array
  {
    $conditions = [];
    $types      = '';
    $params     = [];

    if ($fromDate !== null && $fromDate !== '') {
      $conditions[] = 'created_at >= ?';
      $types       .= 's';
      $params[]     = $fromDate . ' 00:00:00';
    }

    if ($toDate !== null && $toDate !== '') {
      $conditions[] = 'created_at <= ?';
      $types       .= 's';
      $params[]     = $toDate . ' 23:59:59';
    }

    $where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
    return [$where, $params, $types];
  }

  public function getAuditLogs(?string $fromDate = null, ?string $toDate = null, ?int $limit = null, int $offset = 0): array
  {
    [$where, $params, $types] = $this->buildAuditLogFilters($fromDate, $toDate);

    $sql = "SELECT created_at, username, role, action, target_type, target_id, details, ip_address
      FROM audit_logs$where ORDER BY created_at DESC";

    if ($limit !== null) {
      $sql     .= ' LIMIT ? OFFSET ?';
      $types   .= 'ii';
      $params[] = $limit;
      $params[] = $offset;
    }

    $stmt = $this->connection->prepare($sql);

    if (!empty($params)) {
      $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
  }

  public function countAuditLogs(?string $fromDate = null, ?string $toDate = null): int
  {
    [$where, $params, $types] = $this->buildAuditLogFilters($fromDate, $toDate);

    $stmt = $this->connection->prepare("SELECT COUNT(*) FROM audit_logs$where");

    if (!empty($params)) {
      $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    return (int) $stmt->get_result()->fetch_row()[0];
  }

  // ===== IACUC TRAINING CERTIFICATE =====

  public function getCert(int $userId): ?array
  {
    $stmt = $this->connection->prepare(
      "SELECT cert_path, cert_original_name, cert_uploaded_at
      FROM $this->table WHERE id = ? AND cert_path IS NOT NULL"
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
  }

  public function hasCert(int $userId): bool
  {
    return $this->getCert($userId) !== null;
  }

  public function saveCert(int $userId, string $relPath, string $originalName): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE $this->table
      SET cert_path = ?, cert_original_name = ?, cert_uploaded_at = NOW()
      WHERE id = ?"
    );
    $stmt->bind_param('ssi', $relPath, $originalName, $userId);
    return $stmt->execute();
  }

  // ===== WELCOME POPUP =====
  public function markWelcomeSeen(int $id): bool
  {
    $stmt = $this->connection->prepare("UPDATE $this->table SET welcome_seen = 1 WHERE id = ?");
    $stmt->bind_param('i', $id);
    return $stmt->execute();
  }

  // ===== CREATE UPDATE DELETE =====

  public function insertUser(
    string $username,
    string $first_name,
    string $last_name,
    string $email,
    string $passwordHash,
    string $role = 'researcher',
    string $status = 'active',
    ?string $phone_number = null,
    ?string $school = null,
    ?string $sex = null
  ): bool {
    $stmt = $this->connection->prepare(
      "INSERT INTO `$this->table`
      (username, first_name, last_name, email, phone_number, school, sex, password, role, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );

    $stmt->bind_param('ssssssssss', $username, $first_name, $last_name, $email, $phone_number, $school, $sex, $passwordHash, $role, $status);
    return $stmt->execute();
  }

  public function updateUser(int $id, array $input): bool
  {
    $username     = $input['username'];
    $first_name   = $input['first_name'];
    $last_name    = $input['last_name'];
    $email        = $input['email'];
    $phone_number = $input['phone_number'];
    $school       = $input['school'] ?? null;
    $sex          = $input['sex'] ?? null;
    $role         = $input['role'];

    if (!empty($input['password'])) {
      $password = $input['password'];
      $stmt = $this->connection->prepare(
        "UPDATE $this->table 
          SET username=?, first_name=?, last_name=?, email=?, phone_number=?, school=?, sex=?, role=?, password=? 
          WHERE id=?"
      );

      $stmt->bind_param('sssssssssi', $username, $first_name, $last_name, $email, $phone_number, $school, $sex, $role, $password, $id);
    } else {
      $stmt = $this->connection->prepare(
        "UPDATE $this->table 
          SET username=?, first_name=?, last_name=?, email=?, phone_number=?, school=?, sex=?, role=? 
          WHERE id=?"
      );
      $stmt->bind_param('ssssssssi', $username, $first_name, $last_name, $email, $phone_number, $school, $sex, $role, $id);
    }

    return $stmt->execute();
  }

  // ===== EMAIL NOTIFICATION SETTINGS =====
  public function updateEmailNotifications(int $id, bool $enabled): bool
  {
    $val = $enabled ? 1 : 0;
    $stmt = $this->connection->prepare("UPDATE $this->table SET email_notifications = ? WHERE id = ?");
    $stmt->bind_param('ii', $val, $id);
    return $stmt->execute();
  }

  public function updateEmailProviderBlocked(int $id, bool $blocked): bool
  {
    $val = $blocked ? 1 : 0;
    $stmt = $this->connection->prepare("UPDATE $this->table SET email_provider_blocked = ? WHERE id = ?");
    $stmt->bind_param('ii', $val, $id);
    return $stmt->execute();
  }

  public function markEmailProviderUnsubscribed(int $id): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE $this->table SET email_notifications = 0, email_provider_blocked = 1 WHERE id = ?"
    );
    $stmt->bind_param('i', $id);
    return $stmt->execute();
  }

  // ===== DELETE / DEACTIVATE ACCOUNT =====
  public function deleteUser(int $id): bool
  {
    $stmt = $this->connection->prepare("SELECT cert_path FROM $this->table WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $existing = $stmt->get_result()->fetch_assoc();

    $anonUsername   = 'deleted_user_' . $id . '_' . bin2hex(random_bytes(3));
    $anonEmail      = $anonUsername . '@deleted.local';
    $randomPassword = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);

    $stmt = $this->connection->prepare(
      "UPDATE $this->table
          SET username = ?, first_name = 'Deleted', last_name = 'User',
              email = ?, phone_number = NULL, password = ?, status = 'deleted',
              cert_path = NULL, cert_original_name = NULL, cert_uploaded_at = NULL
        WHERE id = ?"
    );
    $stmt->bind_param('sssi', $anonUsername, $anonEmail, $randomPassword, $id);
    $ok = $stmt->execute();

    if ($ok && !empty($existing['cert_path'])) {
      @unlink(dirname(__DIR__, 2) . '/storage/uploads/protocols/' . $existing['cert_path']);
    }

    return $ok;
  }

  public function deactivateUser(int $id): bool
  {
    $stmt = $this->connection->prepare("UPDATE $this->table SET status = 'deactivated' WHERE id = ?");
    $stmt->bind_param('i', $id);
    return $stmt->execute();
  }

  public function reactivateUser(int $id): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE $this->table SET status = 'active' WHERE id = ? AND status = 'deactivated'"
    );
    $stmt->bind_param('i', $id);
    return $stmt->execute();
  }

  // ===== OTHER =====

  public function getPendingUsers(): array
  {
    $stmt = $this->connection->prepare(
      "SELECT id, username, first_name, last_name, email, role, created_at
      FROM $this->table WHERE status = 'pending' ORDER BY created_at ASC"
    );
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
  }

  public function approveUser(int $id): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE $this->table SET status = 'active' WHERE id = ? AND status = 'pending'"
    );
    $stmt->bind_param('i', $id);
    return $stmt->execute();
  }

  public function rejectUser(int $id): bool
  {
    $stmt = $this->connection->prepare(
      "DELETE FROM $this->table WHERE id = ? AND status = 'pending'"
    );
    $stmt->bind_param('i', $id);
    return $stmt->execute();
  }

  // ===== PERSONNEL MANAGEMENT =====

  public function getPersonnelAccounts(): array
  {
    $stmt = $this->connection->prepare(
      "SELECT id, username, first_name, last_name, email, role, status
      FROM $this->table
      WHERE role IN ('staff', 'reviewer') AND status != 'deleted'
      ORDER BY FIELD(role, 'staff', 'reviewer'), first_name, last_name"
    );
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
  }

  public function updateUserRole(int $id, string $role): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE $this->table SET role = ? WHERE id = ? AND role IN ('staff', 'reviewer')"
    );
    $stmt->bind_param('si', $role, $id);
    return $stmt->execute();
  }

  // ===== FORGOT PASSWORD =====

  public function createPasswordReset(int $user_id, string $token): bool
  {
    $stmt = $this->connection->prepare(
      "DELETE FROM password_resets WHERE user_id = ?"
    );
    $stmt->bind_param('i', $user_id);
    $stmt->execute();

    $stmt = $this->connection->prepare(
      "INSERT INTO password_resets (user_id, token, expires_at)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE))"
    );
    $stmt->bind_param('is', $user_id, $token);
    return $stmt->execute();
  }

  public function getPasswordReset(string $token): ?array
  {
    $stmt = $this->connection->prepare(
      "SELECT * FROM password_resets
        WHERE token = ? AND used = 0 AND expires_at > NOW()"
    );
    $stmt->bind_param('s', $token);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
  }

  public function markResetUsed(string $token): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE password_resets SET used = 1 WHERE token = ?"
    );
    $stmt->bind_param('s', $token);
    return $stmt->execute();
  }

  public function updatePassword(int $id, string $hash): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE users SET password = ? WHERE id = ?"
    );
    $stmt->bind_param('si', $hash, $id);
    return $stmt->execute();
  }

  // ===== EMAIL VERIFICATION =====

  public function createEmailVerification(int $user_id, string $token): bool
  {
    $stmt = $this->connection->prepare(
      "DELETE FROM email_verifications WHERE user_id = ?"
    );
    $stmt->bind_param('i', $user_id);
    $stmt->execute();

    $stmt = $this->connection->prepare(
      "INSERT INTO email_verifications (user_id, token, expires_at)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))"
    );
    $stmt->bind_param('is', $user_id, $token);
    return $stmt->execute();
  }

  public function getEmailVerification(string $token): ?array
  {
    $stmt = $this->connection->prepare(
      "SELECT * FROM email_verifications
        WHERE token = ? AND used = 0 AND expires_at > NOW()"
    );
    $stmt->bind_param('s', $token);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
  }

  public function markEmailVerificationUsed(string $token): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE email_verifications SET used = 1 WHERE token = ?"
    );
    $stmt->bind_param('s', $token);
    return $stmt->execute();
  }

  public function markEmailVerified(int $user_id): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE $this->table SET email_verified = 1 WHERE id = ?"
    );
    $stmt->bind_param('i', $user_id);
    return $stmt->execute();
  }

  public function markEmailUnverified(int $user_id): bool
  {
    $stmt = $this->connection->prepare(
      "UPDATE $this->table SET email_verified = 0 WHERE id = ?"
    );
    $stmt->bind_param('i', $user_id);
    return $stmt->execute();
  }

  public function secondsSinceLastVerificationEmail(int $user_id): ?int
  {
    $stmt = $this->connection->prepare(
      "SELECT TIMESTAMPDIFF(SECOND, created_at, NOW()) AS elapsed
        FROM email_verifications WHERE user_id = ?
        ORDER BY created_at DESC LIMIT 1"
    );
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    return $row ? (int) $row['elapsed'] : null;
  }

  // ===== LOGIN ATTEMPTS =====

  public function countRecentAttempts(string $identifier, int $windowSeconds = 900): int
  {
    $stmt = $this->connection->prepare(
      "SELECT COUNT(*) AS cnt FROM login_attempts
        WHERE identifier = ?
        AND attempted_at > DATE_SUB(NOW(), INTERVAL ? SECOND)"
    );
    $stmt->bind_param('si', $identifier, $windowSeconds);
    $stmt->execute();
    return (int) $stmt->get_result()->fetch_assoc()['cnt'];
  }

  public function recordLoginAttempt(string $identifier): void
  {
    $stmt = $this->connection->prepare(
      "INSERT INTO login_attempts (identifier) VALUES (?)"
    );
    $stmt->bind_param('s', $identifier);
    $stmt->execute();
  }

  public function clearLoginAttempts(string $identifier): void
  {
    $stmt = $this->connection->prepare(
      "DELETE FROM login_attempts WHERE identifier = ?"
    );
    $stmt->bind_param('s', $identifier);
    $stmt->execute();
  }

  // ===== STAFF INVITE TOKENS =====

  public function createInviteToken(string $role = 'reviewer', int $hoursValid = 48): string
  {
    $token = bin2hex(random_bytes(32));

    $stmt = $this->connection->prepare(
      "INSERT INTO invite_tokens (token, role, expires_at)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL ? HOUR))"
    );
    $stmt->bind_param('ssi', $token, $role, $hoursValid);
    $stmt->execute();

    return $token;
  }

  public function getValidInviteToken(string $token): ?array
  {
    $stmt = $this->connection->prepare(
      "SELECT * FROM invite_tokens
        WHERE token = ? AND used = 0 AND expires_at > NOW()"
    );
    $stmt->bind_param('s', $token);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc() ?: null;
  }

  public function consumeInviteToken(string $token, int $userId): void
  {
    $stmt = $this->connection->prepare(
      "UPDATE invite_tokens SET used = 1, used_by = ? WHERE token = ?"
    );
    $stmt->bind_param('is', $userId, $token);
    $stmt->execute();
  }
}
